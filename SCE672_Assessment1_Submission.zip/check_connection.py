#!/usr/bin/env python3
import sys
import time

print("[*] Python version:", sys.version)

try:
    import robomaster
    from robomaster import robot
    from robomaster import led
    print("[+] robomaster module loaded from:", robomaster.__file__)
except ImportError as e:
    print("[-] Failed to import robomaster:", e)
    sys.exit(1)

print("[*] Connecting to RoboMaster EP over RNDIS (192.168.42.2)...")
ep = robot.Robot()
try:
    ep.initialize(conn_type="rndis")
    sn = ep.get_sn()
    version = ep.get_version()
    
    battery_level = {"soc": None}
    def b_cb(soc):
        battery_level["soc"] = soc

    ep.battery.sub_battery_info(freq=10, callback=b_cb)
    time.sleep(1.0)
    ep.battery.unsub_battery_info()

    # Flash chassis LED to green to confirm live connection
    ep.led.set_led(comp=led.COMP_ALL, r=0, g=255, b=0, effect=led.EFFECT_ON)

    print("\n" + "="*50)
    print(" >>> ROBOMASTER EP SUCCESSFULLY CONNECTED! <<<")
    print(f" Serial Number   : {sn}")
    print(f" Hardware Version: {version}")
    print(f" Battery Level   : {battery_level['soc']}%")
    print(" Chassis LEDs set to SOLID GREEN")
    print("="*50 + "\n")
finally:
    print("[*] Closing robot connection cleanly...")
    ep.close()
    print("[+] Closed.")
